﻿using UnityEngine;

namespace MB6
{
    public class NPCStatus
    {
        public Vector3 SlopeDirection;
    }
}