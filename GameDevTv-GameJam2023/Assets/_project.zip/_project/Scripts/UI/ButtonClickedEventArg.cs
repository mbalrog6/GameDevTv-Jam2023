﻿using System;
using UnityEngine.UI;

namespace MB6
{
    public class ButtonClickedEventArg : EventArgs
    {
        public Button PressedButton;
    }
}