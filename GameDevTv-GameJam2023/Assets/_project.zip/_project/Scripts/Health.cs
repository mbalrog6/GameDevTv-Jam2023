﻿namespace MB6
{
    public class Health
    {
        
    }
}