﻿using UnityEngine;

namespace MB6
{
    public interface INPCEntity
    {
        public GameObject GetNPCGameObject();
    }
}