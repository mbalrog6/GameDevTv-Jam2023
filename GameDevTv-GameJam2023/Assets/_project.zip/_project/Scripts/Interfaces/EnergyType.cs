﻿namespace MB6
{
    public enum EnergyType
    {
        Light, 
        Dark,
        Either, 
    }
}